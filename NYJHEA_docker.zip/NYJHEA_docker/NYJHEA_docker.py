import psutil
import time
import logging

logging.basicConfig(filename='szamitogep_tevkenysege.log', level=logging.INFO)

while True:
    # CPU használat százalékban
    cpu_percent = psutil.cpu_percent(interval=1)
    # Memória használat százalékban
    memory_percent = psutil.virtual_memory().percent
    # Lemez használat százalékban
    disk_percent = psutil.disk_usage('/').percent
    # Hálózati forgalom
    network_io_counters = psutil.net_io_counters()
    sent_bytes = network_io_counters.bytes_sent
    recv_bytes = network_io_counters.bytes_recv
    
    # Számítógép tevékenységének naplózása
    logging.info(f"CPU Használat: {cpu_percent}%, Memória Használat: {memory_percent}%, Lemez Használat: {disk_percent}%, "
                 f"Elküldött Byte-ok: {sent_bytes}, Fogadott Byte-ok: {recv_bytes}")
    
    # Várakozás 5 másodpercig
    time.sleep(5)